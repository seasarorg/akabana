package examples.flex2.check.service;

import java.util.List;

import examples.flex2.check.dto.CheckDto;

public interface CheckDtoService {
	public CheckDto getCheckDto();
	public List getCheckDtoList();
}
