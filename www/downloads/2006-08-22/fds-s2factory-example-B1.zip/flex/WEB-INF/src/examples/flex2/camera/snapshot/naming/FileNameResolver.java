package examples.flex2.camera.snapshot.naming;

public interface FileNameResolver {
    String getFileName(Object object);
}
