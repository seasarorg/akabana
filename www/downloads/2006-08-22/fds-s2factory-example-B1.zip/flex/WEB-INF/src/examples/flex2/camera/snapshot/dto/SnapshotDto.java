package examples.flex2.camera.snapshot.dto;



public class SnapshotDto {
    private Byte[] source;

    public Byte[] getSource() {
        return source;
    }

    public void setSource(Byte[] source) {
        this.source = source;
    }
}
