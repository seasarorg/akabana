package examples.flex2.camera.snapshot.service;

import examples.flex2.camera.snapshot.dto.SnapshotDto;

public interface SnapshotService {

    public String save(SnapshotDto snapshot);
}
