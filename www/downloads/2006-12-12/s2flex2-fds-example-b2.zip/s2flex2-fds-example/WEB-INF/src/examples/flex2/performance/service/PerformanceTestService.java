package examples.flex2.performance.service;

import java.util.ArrayList;

public interface PerformanceTestService {

    public ArrayList getArray( int size );
}
