package examples.flex2.camera.snapshot.logic;

import examples.flex2.camera.snapshot.dto.SnapshotDto;

public interface SnapshotSaveLogic {

    public String save(SnapshotDto snapshot);
}