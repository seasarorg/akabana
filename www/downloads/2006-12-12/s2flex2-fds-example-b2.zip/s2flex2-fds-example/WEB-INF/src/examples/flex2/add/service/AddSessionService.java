package examples.flex2.add.service;

import examples.flex2.add.dto.AddDto;

public interface AddSessionService {

    
    public AddDto getAddDtoData();
}
